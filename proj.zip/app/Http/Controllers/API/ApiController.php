<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Country;
use App\City;



class ApiController extends Controller
{
    public function getCountries()
    {
        return Country::all();
    }
    public function getCities($id)
    {
        return City::where('country', $id)->get();
    }
}