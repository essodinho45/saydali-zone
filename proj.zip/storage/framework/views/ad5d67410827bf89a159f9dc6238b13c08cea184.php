<?php $__env->startComponent('mail::message'); ?>
# <?php echo e(__('Verified')); ?>


<?php echo e(__('Your email has benn verified, thanks for joining SaydaliZone')); ?>


<?php $__env->startComponent('mail::button', ['url' => 'saydalizone.alkhazensoft.net']); ?>
<?php echo e(__('Visit Us')); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\proj\resources\views/emails/verify.blade.php ENDPATH**/ ?>