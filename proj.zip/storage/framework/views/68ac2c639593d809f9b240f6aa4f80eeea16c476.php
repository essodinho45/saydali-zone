<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8" id="FavAgForm">
            <div class="card">
                <div class="card-header bg-lightkiwi"><?php echo e(__('Add Favourite Distributor')); ?></div>
                <?php if(Auth::user()->user_category_id == 5): ?>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('createFavAg')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">                            
                            
                            <label class="col-md-3 text-right" for="company"><?php echo e(__("Company")); ?> *</label>                            
                                <div class="col-md-6">
                                    <select class="form-control" id="companyFavAg" class="form-control <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="company" value="<?php echo e(old('company')); ?>">
                                        <?php $__currentLoopData = $comps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($comp->id); ?>"><?php echo e($comp->f_name); ?></option>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <div class="form-group row">                            
                            
                            <label class="col-md-3 text-right" for="agent"><?php echo e(__("Agent")); ?> / <?php echo e(__('Distributor')); ?> *</label>                            
                                <div class="col-md-6">
                                    <select class="form-control" id="agentFavAg" class="form-control <?php $__errorArgs = ['agent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="agent" value="<?php echo e(old('agent')); ?>">
                                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($agent->id); ?>"><?php echo e($agent->f_name); ?>&nbsp;<?php echo e($agent->s_name); ?></option>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['agent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3">
                                <button type="submit" class="btn btn-lightkiwi">
                                    <?php echo e(__('Add Favourite Distributor')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script>
    // function pwtt(x)
    // {
    // }
$(document).ready(function() {
    $('select').select2();
  });

  $('#companyFavAg').on('change', function() {
      $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
      });

      var comp = this.value;
      
      $('#agentFavAg').find('option').remove();
        
      $.ajax({
           type:'POST',
           url:'/ajaxFavAgRequest',
           data:{comp:comp},
           success:function(data){
            console.log(data);
            $.each( data, function( key) {
              var o = new Option(data[key].f_name+" "+data[key].s_name, data[key].id);
              /// jquerify the DOM object 'o' so we can use the html method
              $(o).html(data[key].f_name+" "+data[key].s_name);
              $("#agentFavAg").append(o);
            });
           }
      });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/userRelations/FavAg/create.blade.php ENDPATH**/ ?>