<?php $__env->startSection('content'); ?>

<div class="container py-4 text-center">
            <h2><?php echo e($item->name); ?></h2>            
            <small class="text-muted"> <?php if($item->type != null): ?> <?php echo e($item->type->ar_name); ?>&nbsp; <?php endif; ?> <?php if($item->titer != null): ?> <?php echo e($item->titer); ?>&nbsp;<?php echo e(__('mg')); ?> <?php endif; ?> </small>
            <hr>
                <div class="p-2">
                    <div>
                        <?php if($item->composition): ?>
                        <h6><?php echo e(__('Composition')); ?></h6>
                        <p>
                            <?php echo e($item->composition); ?>

                        </p>
                        <?php endif; ?>
                        <?php if($item->dosage): ?>
                        <h6><?php echo e(__('Dosage')); ?></h6>
                        <p>
                            <?php echo e($item->dosage); ?>

                        </p>
                        <?php endif; ?>
                        <?php if($item->descr1): ?>
                        <h6><?php echo e(__('Description 1')); ?></h6>
                        <p>
                            <?php echo e($item->descr1); ?>

                        </p>
                        <?php endif; ?>
                        <?php if($item->properties != null): ?>
                        <h6><?php echo e(__('Properties')); ?></h6>
                        <p>
                            <?php echo e($item->properties); ?>

                        </p>
                        <?php endif; ?>
                        <?php if($item->descr2 != null): ?>
                        <h6><?php echo e(__('Description 2')); ?></h6>
                        <p>
                            <?php echo e($item->descr2); ?>

                        </p>
                        <?php endif; ?>
                        <?php if($item->package != null): ?>
                        <h6><?php echo e(__('Package')); ?></h6>
                        <p>
                            <?php echo e($item->package); ?>

                        </p>
                        <?php endif; ?>
                        <?php if($item->storage != null): ?>
                        <h6><?php echo e(__('Storage')); ?></h6>
                        <p>
                            <?php echo e($item->storage); ?>

                        </p>
                        <?php endif; ?>
                        <hr>
                        <div class="row col-12">
                            <div class="col-md-3">
                            <h6><?php echo e(__('Price')); ?></h6>
                            <p>
                                <?php echo e($item->price); ?> <?php echo e(__('S.P.')); ?>

                            </p>
                            </div>
                            <div class="col-md-3">
                            <?php if($item->customer_price != null): ?>
                            <h6><?php echo e(__('Customer Price')); ?></h6>
                            <p>
                                <?php echo e($item->customer_price); ?> <?php echo e(__('S.P.')); ?>

                            </p>
                            <?php endif; ?>
                            </div>
                            <div class="col-md-3 offset-md-3">
                                <span><?php echo e(__('Produced By: ')); ?><i><?php echo e($item->company->f_name); ?></i> .</span>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $item->company->id): ?>
                        <form action="<?php echo e(route('deleteItem',['id' => $item->id])); ?>" method="POST" class="my-2 float-right">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE">
                                <a class="btn btn-secondary" href="<?php echo e(route('editItem', ['id'=>$item->id])); ?>"><?php echo e(__('Edit')); ?></a>
                                <button class="btn btn-danger" type="submit">
                                    <?php echo e(__("Delete Item")); ?>

                                </button>
                        </form>
                    <?php elseif(Auth::user()->user_category_id == 5): ?>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="quantity<?php echo e($item->id); ?>" class="float-left text-left"><?php echo e(__('Quantity')); ?></label>
                            <input type="number" placeholder="0" id="quantity<?php echo e($item->id); ?>" min="0" class="form-control form-control" name="quantity<?php echo e($item->id); ?>" value="0" onchange="quantityChange(<?php echo e($item->id); ?>)" required>
                        </div>
                        <div class="col-md-4">
                            <label for="reciever_id<?php echo e($item->id); ?>" class="float-left text-left"><?php echo e(__('Reciever')); ?></label>
                            <select id="reciever_id<?php echo e($item->id); ?>" class="form-control form-control" name="reciever_id<?php echo e($item->id); ?>" value="" required>
                                <option disabled><?php echo e(__('please select quantity first')); ?></option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="sender_remark_txt" class="float-left text-left"><?php echo e(__('Sender Remark')); ?></label>
                            <textarea id="sender_remark_txt" class="form-control w-100" rows="1"></textarea>
                        </div>
                    <div class="col-12">
                        <button type="button" class="btn btn-primary disabled btn mt-2 float-right"  onclick="ajaxSendtoCart(<?php echo e($item->id); ?>, false)" disabled id="i_btn<?php echo e($item->id); ?>">
                            <?php echo e(__('Add to Cart')); ?>

                        </button>
                    </div>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
function ajaxSendtoCart(item = null, isBasket){
    isBasket = false;
    sender_remark = $('#sender_remark_txt').val();
    quantity = $('#quantity'+item).val();
    reciever_id = $('#reciever_id'+item).val();
if(quantity>0){
    $.ajax({
    type:'POST',
    url:'/addToCart',
    data:{item_id: item,
        isBasket: isBasket,
        reciever_id: reciever_id,
        quantity: quantity, 
        sender_remark: sender_remark},
    success:function(data){
        console.log(data);
        location.reload();
    },
    error:function(error){
        console.log(error);
    }
});}
}
function quantityChange(id){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
                });

                $.ajax({
                type:'POST',
                url:'/cart/postItem',
                data:{id: id, isBasket: false},
                success:function(data){
                        console.log(data);
                        $("#reciever_id"+id).find('option').remove();
                        $.each( data, function( key) {
                        var o = new Option(data[key].f_name, data[key].id);
                        var sname = (data[key].s_name == null) ? '' : data[key].s_name ;
                        /// jquerify the DOM object 'o' so we can use the html method
                        $(o).html(data[key].f_name + " " + sname);
                        $("#reciever_id"+id).append(o);
                        });
                        $('#i_btn'+id).removeAttr('disabled').removeClass('disabled');                  
                },
                error:function(error){
                    console.log(error);
                }
            });  
          }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/items/show.blade.php ENDPATH**/ ?>