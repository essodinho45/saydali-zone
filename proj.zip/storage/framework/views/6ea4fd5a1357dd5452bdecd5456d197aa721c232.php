<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Distributor')); ?> <?php echo e(__('to')); ?> <?php echo e($ag->f_name); ?>&nbsp;<?php if($ag->s_name): ?><?php echo e($ag->s_name); ?><?php endif; ?></div>

                <div class="card-body">
                    <?php if(auth()->guard()->check()): ?>
                    <form method="POST" action="/addDist/<?php echo e($ag->id); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                                <label class="col-md-3 text-right" for="dist"><?php echo e(__("Distributor")); ?> *</label>
                                <div class="col-md-6">
                                    <select class="form-control w-100" id="dist" class="form-control <?php $__errorArgs = ['dist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dist" value="<?php echo e(old('dist')); ?>" required>
                                        <?php $__currentLoopData = $dists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dist->id); ?>"><?php echo e($dist->f_name); ?>&nbsp; <?php if($dist->s_name): ?><?php echo e($dist->s_name); ?><?php endif; ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['dist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3">
                                <button type="submit" class="btn btn-lightkiwi">
                                    <?php echo e(__('Add')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                        
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/userRelations/add.blade.php ENDPATH**/ ?>