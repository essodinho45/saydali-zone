<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
    <div class="container py-4">
            <h3 class="w-75 d-inline-block"><?php echo e(__('Cart')); ?></h3>
            <hr>
        <?php $__currentLoopData = $carts->groupBy('reciever_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-4">
          <div class="row">
                  <img class="img-fluid rounded-circle mx-2 mb-4" width="36px" src="<?php echo e(asset($cart->first()->reciever->logo_image)); ?>">
                  <h4><?php echo e(__("Reciever")); ?> : <?php echo e($cart->first()->reciever->f_name); ?> <?php echo e($cart->first()->reciever->s_name); ?></h4>
          </div>
          <div class="table-responsive">
          <table class="table table-hover table-sm table-bordered mt-2" id="CartTable">
              <thead>
              <tr>
                  <th scope="col">#</th>
                  <th scope="col"><?php echo e(__('Item')); ?></th>
                  <th scope="col"><?php echo e(__('Producer')); ?></th>
                  <th scope="col"><?php echo e(__('Quantity')); ?></th>
                  <th scope="col"><?php echo e(__('Free Quantity')); ?></th>
                  <th scope="col"><?php echo e(__('Price')); ?></th>
                  <th scope="col"><?php echo e(__('Actions')); ?></th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr <?php if($item->is_basket): ?> data-toggle="collapse" class="clickable" data-target="#collapseBItems<?php echo e($item->id); ?>" aria-expanded="false" aria-controls="collapseBItems<?php echo e($item->id); ?>" <?php endif; ?>>
                      <th scope="row" <?php if($item->is_basket): ?> rowspan="2" <?php endif; ?> ><?php echo e($item->id); ?></th>
                      <td><?php if($item->is_basket): ?><?php echo e(__("Basket")); ?><?php else: ?><?php echo e($item->item->name); ?><?php endif; ?></td>
                      <td><?php echo e($item->item->company->f_name); ?></td>
                      <td><?php echo e($item->quantity); ?></td>
                      <td><?php if(!$item->is_basket): ?><?php echo e($item->free_quant); ?><?php endif; ?></td>
                      <td><?php echo e($item->price); ?></td>
                      <td>
                        <form action="<?php echo e(route('deleteCart',['id' => $item->id])); ?>" method="POST" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button class="btn btn-danger btn-sm" type="submit">
                            <?php echo e(__("Delete")); ?>

                        </button>
                        </form>
                      </td>
                  </tr>
                  <?php if($item->is_basket): ?>
                  <tr>
                    <td colspan="6">
                        <div class="collapse" id="collapseBItems<?php echo e($item->id); ?>">
                            <?php $__currentLoopData = $baskets->where('id',$item->item_id)->first()->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                    <?php echo e($itemm->name ." ". $itemm->type->ar_name ." ". $itemm->titer); ?> : <b><?php echo e($itemm->pivot->quantity); ?></b>
                                <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </td>
                  </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
            <a class="btn btn-secondary" href="#" title="<?php echo e(__('Insert Sender Remark')); ?>" onclick="showModal(<?php echo e($cart->first()->reciever->id); ?>)"><i class="fas fa-comment"></i></a>
            <a class="btn btn-secondary" href="#" onclick="storeOrderAjax(<?php echo e($cart->first()->reciever->id); ?>)"><?php echo e(__('Send Order')); ?></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($carts->count()!=0): ?>
          <a class="btn btn-secondary float-right" href="#" onclick="storeOrderAjax()"><?php echo e(__('Send All Orders')); ?></a>
        <?php endif; ?>
    </div>
        <!-- Modal -->
        <div class="modal fade" id="sender_remark" tabindex="-1" role="dialog" aria-labelledby="sender_remarkLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
              <h5 class="modal-title" id="sender_remarkLabel"><?php echo e(__('Add to Cart')); ?></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
              </div>
              <div class="modal-body">
                  <input type="hidden" id="reciever">
                  <label for="remark"><?php echo e(__('Sender Remark')); ?></label>
                  <textarea id="remark" class="form-control w-100"></textarea>
              </div>
              <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
              <button type="button" class="btn btn-primary" onclick="storeOrderAjax()"><?php echo e(__('Add to Cart')); ?></button>
              </div>
          </div>
          </div>
      </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<script>
  function showModal(id)
  {
    $('#reciever').val(id);
    $('#sender_remark').modal('show');
  }
  function storeOrderAjax(reciever = null)
  {
    if(reciever == null)
      reciever = $('#reciever').val();
    remark = $('#remark').val();
    $.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });

    $.ajax({
      type:'POST',
      url:"<?php echo e(route('storeOrder')); ?>",
      data:{reciever:reciever, remark:remark},
      success:function(data){
        console.log(data);
        location.href = "/orders";
      },
       error:function(error){
        console.log(error);
       }
   });    
  }
  $(document).ready(function() {
            $('#CartTable').DataTable({fixedHeader: true, 
                "info":     false,
                "oLanguage": {"sSearch": "<i class='fas fa-search'></i>"}
              });
        tablesFunc('CartTable');

          } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/orders/cart.blade.php ENDPATH**/ ?>