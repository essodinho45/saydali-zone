<?php if(Auth::user()->user_category_id == 2 || Auth::user()->user_category_id == 3 || Auth::user()->user_category_id == 0): ?>
<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
        <div class="container py-4">
                <form action="<?php echo e(route('storeOffer')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                                <label class="col-md-3" for="offer_type"><?php echo e(__("Offer Type")); ?></label>
                                <div class="col-md-6">
                                        <select class="form-control" id="offer_type" class="form-control <?php $__errorArgs = ['offer_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="offer_type" value="<?php echo e(old('offer_type')); ?>">
                                        <option value="1"><?php echo e(__('Discount')); ?></option>
                                        <option value="2"><?php echo e(__('Addetional Quantity')); ?></option>
                                        <option value="3"><?php echo e(__('Basket')); ?></option>
                                        </select>
                                        <?php $__errorArgs = ['offer_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <hr>
                        <div class="form-group row">
                                <label class="col-md-3" for="from_date"><?php echo e(__("From Date")); ?></label>
                                <div class="col-md-3">
                                        <input id="from_date" type="date" class="form-control <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="from_date" value="<?php echo e(old('from_date')); ?>">

                                        <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <label class="col-md-3" for="to_date"><?php echo e(__("To Date")); ?></label>
                                <div class="col-md-3">
                                        <input id="to_date" type="date" class="form-control <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="to_date" value="<?php echo e(old('to_date')); ?>">

                                        <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <hr>
                        <div id="offer">
                                <div class="form-group row">
                                        <label class="col-md-3" for="item_id"><?php echo e(__("Item")); ?></label>
                                        <div class="col-md-6">
                                                <select class="form-control" id="item_id" class="form-control <?php $__errorArgs = ['item_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="item_id" value="<?php echo e(old('item_id')); ?>">
                                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> <?php echo e($item->type->ar_name); ?> <?php echo e($item->titer); ?> <?php echo e(__("mg")); ?> - <?php echo e($item->company->f_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['item_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>

                                <div class="form-group row">
                                        <label class="col-md-3" for="discount"><?php echo e(__("Discount")); ?> %</label>
                                        <div class="col-md-6">
                                                <input id="discount" type="number" class="form-control <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="discount" value="<?php echo e(old('discount')); ?>">
    
                                                <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>

                                <div class="form-group row">
                                        <label class="col-md-3" for="quant"><?php echo e(__("Minimum quantity for offer")); ?></label>
                                        <div class="col-md-6">
                                                <input id="quant" type="number" class="form-control <?php $__errorArgs = ['quant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="quant" value="<?php echo e(old('quant')); ?>">
    
                                                <?php $__errorArgs = ['quant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>

                                <div class="form-group row" style="display:none;">
                                        <label class="col-md-3" for="free_item"><?php echo e(__("Free Item")); ?></label>
                                        <div class="col-md-6">
                                                <select class="form-control" id="free_item" class="form-control <?php $__errorArgs = ['free_item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="free_item" value="<?php echo e(old('free_item')); ?>">
                                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> <?php echo e($item->type->ar_name); ?> <?php echo e($item->titer); ?> <?php echo e(__("mg")); ?> - <?php echo e($item->company->f_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['free_item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>

                                <div class="form-group row" style="display:none;">
                                        <label class="col-md-3" for="free_quant"><?php echo e(__("Free quantity")); ?></label>
                                        <div class="col-md-6">
                                                <input id="free_quant" type="number" class="form-control <?php $__errorArgs = ['free_quant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="free_quant" value="<?php echo e(old('free_quant')); ?>">
    
                                                <?php $__errorArgs = ['free_quant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>

                                <div class="form-group row">
                                        <label class="col-md-3" for="remark"><?php echo e(__("Remark")); ?></label>
                                        <div class="col-md-6">
                                                <textarea class="form-control" rows="5" id="remark" name="remark"></textarea>

                                                <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>

                        </div>
                        <div id="basket" style="display:none;">
                                <table class="table table-hover table-sm mt-2" id="ItemsTable">
                                        <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col"><?php echo e(__('Name')); ?></th>
                                            <th scope="col"><?php echo e(__('Producer')); ?></th>
                                            <th scope="col"><?php echo e(__('Price')); ?></th>
                                            <th scope="col"><?php echo e(__('Customer Price')); ?></th>
                                            <th scope="col"><?php echo e(__('Type')); ?></th>
                                            <th scope="col"><?php echo e(__('Quantity')); ?></th>
                                            <th scope="col"><?php echo e(__('Actions')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                <th scope="row"><?php echo e($item->id); ?></th>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->company->f_name); ?></td>
                                                <td><?php echo e($item->price); ?></td>
                                                <td><?php echo e($item->customer_price); ?></td>
                                                <td><?php echo e($item->type->ar_name); ?></td>
                                                <td><input id="item_quant_<?php echo e($item->id); ?>" type="number" class="form-control w-50" name="item_quant_<?php echo e($item->id); ?>" value="0"></td>
                                                <td>
                                                    <a class="btn btn-primary btn-sm" href="#" onclick="addToBasket(<?php echo e($item->id); ?>)"><?php echo e(__('Add to Basket')); ?></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <hr>
                                    <div class="form-group row">
                                        <label class="col-md-3" for="price"><?php echo e(__("Price")); ?></label>
                                        <div class="col-md-6">
                                                <input id="price" type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" value="<?php echo e(old('price')); ?>">
    
                                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>
                        </div>
                                                        
                        <input type="hidden" name="basket_info" id="basket_info">
                        <button class="btn btn-info" type="submit">
                                <?php echo e(__("Save Offer")); ?>

                        </button>
                </form>
                
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<script>
        var basketItems = [];
        function addToBasket(id) {
                basketItems.push(id + "-" + $('#item_quant_'+id).val());
                $("#basket_info").val(basketItems);
        }
        $(document).ready(function() {
        // itemsOfferAjax();
        $('#ItemsTable').DataTable();
        $('#item_id').select2();
        $('#free_item').select2();
        });
        $('#offer_type').on('change', function() {
                if($('#offer_type').val() == 3)
                {
                        $('#offer').hide();
                        $('#basket').show();
                }
                else
                {
                        $('#basket').hide();
                        $('#offer').show();
                        if($('#offer_type').val() == 2)
                        {
                                $("#discount").parent().parent().hide();
                                $("#free_item").parent().parent().show();
                                $("#free_quant").parent().parent().show();
                        }
                        else
                        {
                                $("#free_item").parent().parent().hide();
                                $("#free_quant").parent().parent().hide();
                                $("#discount").parent().parent().show();
                        }
                }
        });
</script>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/offers/create.blade.php ENDPATH**/ ?>