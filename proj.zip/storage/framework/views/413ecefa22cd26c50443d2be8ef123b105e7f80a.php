<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
    <div class="container py-4">
            <h3 class="w-75 d-inline-block"><?php echo e(__('Manage Users')); ?></h3>
            <button class="btn btn-primary float-right" type="submit" onclick="window.location='<?php echo e(route('createUserForm')); ?>'">
                <?php echo e(__("Create User")); ?>

            </button>
            <hr>
            <div class="table-responsive">
        <table class="table table-hover table-sm table-bordered nowrap mt-2" id="usersTable">
            <thead>
            <tr>
                <th scope="col" class="no_srch">#</th>
                <th scope="col"><?php echo e(__('Name')); ?></th>
                <th scope="col"><?php echo e(__('Username')); ?></th>
                <th scope="col"><?php echo e(__('Country')); ?></th>
                <th scope="col"><?php echo e(__('Region')); ?></th>
                <th scope="col" class="no_srch"><?php echo e(__('Telephone 1')); ?></th>
                <th scope="col" class="no_srch"><?php echo e(__('E-Mail Address')); ?></th>
                <th scope="col"><?php echo e(__('Category')); ?></th>
                <th scope="col" class="no_srch"><?php echo e(__('Actions')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr <?php if($user->freezed == true): ?> class='table-danger' <?php endif; ?> >
                    <th scope="row"><?php echo e($user->id); ?></th>
                    <td><?php echo e($user->f_name); ?>&nbsp;<?php echo e($user->s_name); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->itsCountry->ar_name); ?></td>
                    <td><?php echo e($user->itsCity->ar_name); ?></td>
                    <td><?php echo e($user->tel1); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e(__($user->category->name)); ?></td>
                    <td>
                        <?php if($user->email_verified_at == null): ?>
                            <a class="btn btn-info btn-sm" id="verBtn<?php echo e($user->id); ?>" href="#" onclick="verUsrAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Verify')); ?></a>
                        <?php endif; ?>
                        <?php if($user->user_category_id != 0): ?>
                            <a class="btn btn-secondary btn-sm" href="/showUsr/<?php echo e($user->id); ?>"><?php echo e(__('Show')); ?></a>
                            <?php if($user->freezed == false): ?>
                                <a class="btn btn-danger btn-sm" id="frzUsrBtn<?php echo e($user->id); ?>" href="#" onclick="frzUsrAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Freeze')); ?></a>
                            <?php elseif($user->freezed == true): ?>
                                <a class="btn btn-secondary btn-sm" id="unfrzUsrBtn<?php echo e($user->id); ?>" href="#" onclick="unfrzUsrAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Unfreeze')); ?></a>
                            <?php endif; ?>
                            <?php if($user->items->count()==0
                            && $user->ordersFromUser->count()==0
                            && $user->ordersToUser->count()==0
                            && $user->cartsFromUser->count()==0
                            && $user->cartsToUser->count()==0
                            && $user->posts->count()==0
                            && $user->offers->count()==0
                            && $user->quantities->count()==0
                            && $user->baskets->count()==0): ?>
                                <form action="<?php echo e(route('deleteUser',['id' => $user->id])); ?>" method="POST" class="d-inline-block">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-danger btn-sm" type="submit">
                                        <?php echo e(__("Delete")); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
            </tbody>
        </table>
    </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<script>
    $(document).ready(function() {
        $('#usersTable thead tr').clone(true).appendTo( '#usersTable thead' );
            $('#usersTable thead tr:eq(1) th').each( function (i) {
                var hide= '';
                if($(this).hasClass('no_srch'))
                    hide = 'd-none'
                var title = $(this).text();
                $(this).html( '<input type="text" class="form-control form-control-sm '+hide+'" placeholder="'+title+'" />' );
                var attr = $(this).attr('data-priority');

                // For some browsers, `attr` is undefined; for others,
                // `attr` is false.  Check for both.
                if (!(typeof attr !== typeof undefined && attr !== false) && !$(this).hasClass('d-none')) {
                    $(this).addClass('d-none d-lg-table-cell');
                }
        
                $( 'input', this ).on( 'keyup change', function () {
                    if ( table.column(i).search() !== this.value ) {
                        table
                            .column(i)
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
      $('#usersTable').DataTable( {
                orderCellsTop: true,
                fixedHeader: true,
                "info":     false,
                "oLanguage": {"sSearch": "<i class='fas fa-search'></i>"}
            } );
            tablesFunc('usersTable');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/userRelations/allUsers.blade.php ENDPATH**/ ?>