<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="container py-4">
    <h3 class="w-75 d-inline-block"><?php echo e(__('Orders')); ?></h3>
    <?php if(Auth::user()->user_category_id != 1): ?>
        <hr>
    <div class="table-responsive">
    <table class="table table-hover table-sm table-bordered nowrap mt-2" id="OrdersTable">
        <thead>
        <tr>
            <th scope="col">#</th>
            <?php if(Auth::user()->user_category_id == 5): ?>
                <th scope="col"><?php echo e(__('Reciever Name')); ?></th>
            <?php else: ?>
                <th scope="col"><?php echo e(__('Sender Name')); ?></th>
            <?php endif; ?>
            <th scope="col"><?php echo e(__('Date')); ?></th>
            <th scope="col"><?php echo e(__('Time')); ?></th>
            <th scope="col"><?php echo e(__('Verified')); ?></th>
            <th scope="col"><?php echo e(__('Actions')); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <th scope="row"><?php echo e($order->id); ?></th>
                <?php if(Auth::user()->user_category_id == 5): ?>
                    <td><?php echo e($order->reciever->f_name); ?> <?php echo e($order->reciever->s_name); ?></td>
                <?php else: ?>
                    <td><?php echo e($order->sender->f_name); ?> <?php echo e($order->sender->s_name); ?></td>
                <?php endif; ?>
                <td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                <td class="cvrt2tz"><?php echo e($order->created_at->format('H:i:s')); ?></td>
                <td>
                    <?php if($order->verified_at!=null): ?>
                    <?php echo e($order->verified_at->format('d/m/Y')); ?>

                    <?php else: ?>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->pivot->verified_at != null): ?>
                            <?php echo e(__('partially verified at')); ?>: <?php echo e(date('d/m/Y', strtotime($item->pivot->verified_at))); ?>

                            <?php break; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </td>
                <td>
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('showOrder', ['id'=>$order->id])); ?>"><?php echo e(__('Show')); ?></a>
                    <?php if(Auth::user()->id == 0): ?>
                        <form action="<?php echo e(route('deleteOrder',['id' => $order->id])); ?>" method="POST" class="d-inline-block">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-danger btn-sm" type="submit">
                                <?php echo e(__("Delete")); ?>

                            </button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fixedHeader.bootstrap4.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fixedHeader.bootstrap4.min.css')); ?>" rel="stylesheet">
<script>
    $(document).ready(function() {
      $('#OrdersTable').DataTable({fixedHeader: true, 
                "info":     false,
                "oLanguage": {"sSearch": "<i class='fas fa-search'></i>"}
            });
      $(".cvrt2tz").each(function(){
          $(this).html(toLocalTime($(this).text()));
        });
        tablesFunc('OrdersTable');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/orders/index.blade.php ENDPATH**/ ?>