<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
        <div class="container py-4">
        <h4><?php echo e(__("please insert excel file in following form:")); ?></h4>
        <br>
                <table class="table table-hover table-sm mt-2" id="ItemsTable">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo e(__('Name')); ?></th>
                            <th scope="col"><?php echo e(__('Barcode')); ?></th>
                            <th scope="col"><?php echo e(__('Composition')); ?></th>
                            <th scope="col"><?php echo e(__('Dosage')); ?></th>
                            <th scope="col"><?php echo e(__('Description 1')); ?></th>
                            <th scope="col"><?php echo e(__('Description 2')); ?></th>
                            <th scope="col"><?php echo e(__('Price')); ?></th>
                            <th scope="col"><?php echo e(__('Customer Price')); ?></th>
                            <th scope="col"><?php echo e(__('Titer')); ?></th>
                            <th scope="col"><?php echo e(__('Item Type')); ?></th>
                            <th scope="col"><?php echo e(__('Item Category')); ?></th>
                            <th scope="col"><?php echo e(__('Properties')); ?></th>
                            <th scope="col"><?php echo e(__('Package')); ?></th>
                            <th scope="col"><?php echo e(__('Storage')); ?></th>
                            
                        </tr>
                        </thead>

                        <tbody>
                            <tr style="font-size:0.8rem">
                                <td><?php echo e(__("product name")); ?></td>
                                <td><?php echo e(__("product barcode")); ?></td>
                                <td><?php echo e(__("product composition")); ?></td>
                                <td><?php echo e(__("dosage of product")); ?></td>
                                <td><?php echo e(__("product indications")); ?></td>
                                <td><?php echo e(__("product side effects")); ?></td>
                                <td><?php echo e(__("price for pharmacist")); ?></td>
                                <td><?php echo e(__("price for customers")); ?></td>
                                <td><?php echo e(__("titer by milligrams")); ?></td>
                                <td><?php echo e(__("item type")); ?></td>
                                <td><?php echo e(__("item category")); ?></td>
                                <td><?php echo e(__("properties of product")); ?></td>
                                <td><?php echo e(__("product packaging")); ?></td>
                                <td><?php echo e(__("conditions of storage")); ?></td>
                                
                            </tr>
                        </tbody>
                    </table>
                    <hr>
                    <p>
                        <?php echo e(__('Add the following fields afterwards for second language')); ?>:<br>
                        <b>
                            <?php echo e(__('Name')); ?><br>
                            <?php echo e(__('Composition')); ?><br>
                            <?php echo e(__('Dosage')); ?><br>
                            <?php echo e(__('Description 1')); ?><br>
                            <?php echo e(__('Description 2')); ?><br>
                            <?php echo e(__('Properties')); ?><br>
                            <?php echo e(__('Package')); ?><br>
                            <?php echo e(__('Storage')); ?><br>
                        </b>                        
                    </p>
                    <?php if(Auth::user()->category->id == 0): ?><p><?php echo e(__('add company field last')); ?></p><?php endif; ?>
                <form action="<?php echo e(route('storeItems')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row mt-4">
                            <div class="col-md-12">
                                 <input type="file" class="form-control-file" name="items_file" id="items_file">
                            </div>
                        </div>
                        <!-- Input tags go here -->
                        <button class="btn btn-info" type="submit">
                            <?php echo e(__("Import Items")); ?>

                        </button>
                </form>
                <hr>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/items/import.blade.php ENDPATH**/ ?>