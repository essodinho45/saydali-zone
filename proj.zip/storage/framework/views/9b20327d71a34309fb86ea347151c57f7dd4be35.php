<?php $__env->startSection('content'); ?>

<div class="container py-4">
            <h2><?php echo e($post->title); ?></h2>            
            <small class="text-muted"><?php echo e(__('Last updated')); ?> <?php echo e($post->updated_at->diffForHumans()); ?></small>
            <br>
                <div class="p-2">
                    <div>
                        <p>
                            <?php echo e($post->content); ?>

                        </p>
                        <span><?php echo e(__('Posted By: ')); ?><i><?php echo e($post->author->f_name); ?>&nbsp;<?php echo e($post->author->s_name); ?></i> .</span>
                    </div>
                    
                </div>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $post->author->id): ?>
                        <form action="<?php echo e(route('deletePost',['id' => $post->id])); ?>" method="POST" class="mt-2 float-right">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE">
                                <a class="btn btn-secondary" href="<?php echo e(route('editPost', ['id'=>$post->id])); ?>"><?php echo e(__('Edit')); ?></a>
                                <button class="btn btn-danger" type="submit">
                                    <?php echo e(__("Delete Post")); ?>

                                </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/posts/show.blade.php ENDPATH**/ ?>