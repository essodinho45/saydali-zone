<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
        <div class="container py-4">
                <form action="<?php echo e(route('storePost')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                                <label for="title"><?php echo e(__('Title')); ?></label>
                                <input type="text" class="form-control" id="title" name="title">
                        </div>
                        <div class="form-group">
                                <label for="content"><?php echo e(__('Content')); ?></label>
                                <textarea class="form-control" rows="5" id="content" name="content"></textarea>
                        </div>
                        <!-- Input tags go here -->
                        <button class="btn btn-info" type="submit">
                            <?php echo e(__("Save Post")); ?>

                        </button>
                </form>
                
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/posts/create.blade.php ENDPATH**/ ?>