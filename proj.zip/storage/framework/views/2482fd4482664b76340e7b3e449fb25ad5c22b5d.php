<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="container py-4">
    <h3 class="w-75 d-inline-block"><?php echo e(__('Favourite Distributors')); ?></h3>
    <?php if(Auth::user()->user_category_id == 5): ?>
    <button class="btn btn-secondary float-right" type="submit" onclick="window.location='<?php echo e(route('addFav')); ?>'">
        <?php echo e(__("Add Favourite Distributor")); ?>

    </button>
    <hr>
    <table class="table table-hover table-sm table-bordered nowrap mt-2" id="FavAgTable">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col"><?php echo e(__('Distributor Name')); ?></th>
            <th scope="col"><?php echo e(__('Company')); ?></th>
            <th scope="col"><?php echo e(__('Actions')); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <th scope="row"><?php echo e($agent->id); ?></th>
                <td><?php echo e($agent->f_name); ?>&nbsp;<?php echo e($agent->s_name); ?></td>
                <td><!-- كمل بالبيت -->
                        <?php echo e($agent->username); ?>

                </td>
                <td>
                    <form action="<?php echo e(route('removeFavAg',['id' => $agent->id, 'comp_id'=>$agent->pivot->comp_id])); ?>" method="POST" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button class="btn btn-danger btn-sm" type="submit" title='<?php echo e(__("Delete")); ?>'>
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fixedHeader.bootstrap4.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fixedHeader.bootstrap4.min.css')); ?>" rel="stylesheet">
<script>
    $(document).ready(function() {
      $('#OrdersTable').DataTable({responsive: true, fixedHeader: true});      
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/userRelations/FavAg/index.blade.php ENDPATH**/ ?>