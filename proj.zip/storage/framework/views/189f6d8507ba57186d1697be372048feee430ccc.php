<table class="action" align="center" width="100%" cellpadding="0" cellspacing="0" role="presentation">
    <tr>
        <td align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
                <tr>
                    <td align="center">
                        <table border="0" cellpadding="0" cellspacing="0" role="presentation">
                            <tr>
                                <td>
                                    <a href="<?php echo e($url); ?>" class="button button-<?php echo e($color ?? 'primary'); ?>" target="_blank"><?php echo e($slot); ?></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<?php /**PATH C:\xampp\proj\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/button.blade.php ENDPATH**/ ?>