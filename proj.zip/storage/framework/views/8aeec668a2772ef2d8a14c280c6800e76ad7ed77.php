<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8" id="ads_form">
            <div class="card">
                <div class="card-header bg-lightkiwi"><?php echo e(__('Create Ad')); ?></div>

                <div class="card-body">
                    <form method="POST" id="adForm"  action="<?php echo e(route('storeAds')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                                <label class="col-md-3 text-right" for="user_id"><?php echo e(__("User")); ?></label>
                                <div class="col-md-6">
                                    <select class="form-control" id="user_id" class="form-control <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="user_id" value="<?php echo e(old('user_id')); ?>">
                                        
                                        <?php $__currentLoopData = $usrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($comp->id); ?>" <?php if(old('user_id') == $comp->id): ?> selected <?php endif; ?>><?php echo e($comp->f_name); ?> &nbsp; <?php if($comp->s_name != null): ?><?php echo e($comp->s_name); ?><?php endif; ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <div class="form-group row">                            
                            
                            <label class="col-md-3 text-right" for="category"><?php echo e(__("Position")); ?> *</label>
                                <div class="col-md-6">
                                    <select class="form-control" id="position" class="form-control <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="position" value="<?php echo e(old('position')); ?>">
                                        <option value="1"><?php echo e(__('Home Page')); ?></option>
                                        <option value="3"><?php echo e(__('Control Panel')); ?> 1</option>
                                        <option value="4"><?php echo e(__('Control Panel')); ?> 2</option>
                                        <option value="5"><?php echo e(__('Items')); ?> 1</option>
                                        <option value="6"><?php echo e(__('Items')); ?> 2</option>
                                    </select>
                                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label class="col-md-3 text-right" for="from_date"><?php echo e(__("From Date")); ?></label>
                                <div class="col-md-6">
                                        <input id="from_date" type="date" class="form-control <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="from_date" value="<?php echo e(old('from_date')); ?>">

                                        <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <div class="form-group row">                                
                                <label class="col-md-3 text-right" for="to_date"><?php echo e(__("To Date")); ?></label>
                                <div class="col-md-6">
                                        <input id="to_date" type="date" class="form-control <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="to_date" value="<?php echo e(old('to_date')); ?>">

                                        <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>

                        <div id="e3img" class="form-group row" style="display: none;">
                                <label class="col-md-3 text-right" for="ad_image"><?php echo e(__("Image")); ?></label>
                                <div class="col-md-6">
                                     <input type="file" class="form-control-file" name="ad_image" id="ad_image">
                                </div>
                        </div>

                        <div id="e3txt" class="form-group row">                                
                                <label class="col-md-3 text-right" for="text"><?php echo e(__("Text")); ?></label>
                                <div class="col-md-6">
                                        <textarea class="form-control" rows="3" id="text" name="text" form="adForm"></textarea>

                                        <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>

                        <div class=" form-check offset-md-3">
                            <input class="form-check-input" name="keep" type="checkbox" id="keep"/>
                            <label class="form-check-label" for="keep">
                              <?php echo e(__("Keep ad after end of date")); ?>

                            </label>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3 mt-2">
                                <button type="submit" class="btn btn-lightkiwi">
                                    <?php echo e(__('Create Ad')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script>
    // function pwtt(x)
    // {
    // }
$(document).ready(function() {
    $('select').select2();
  });
  $('#position').on('change', function() {
    if(this.value == 1)
    {
        $('#e3txt').show();
        $('#e3img').hide();
    }
    else{
        $('#e3txt').hide();
        $('#e3img').show();
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/ads/create.blade.php ENDPATH**/ ?>