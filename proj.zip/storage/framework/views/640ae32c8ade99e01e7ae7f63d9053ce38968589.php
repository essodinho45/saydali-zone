
    <!-- Scripts -->
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" defer></script>
    <!-- Styles -->
    <link href="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" rel="stylesheet"><?php /**PATH C:\xampp\proj\resources\views/layouts/table.blade.php ENDPATH**/ ?>