<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
    <div class="container py-4">
            <?php if(\Route::currentRouteName() == 'distributors'): ?>
                <h3 class="w-75 d-inline-block"><?php echo e(__('Distributors')); ?></h3>
                <?php if(Auth::user()->category->id == 2): ?>
                    <button class="btn btn-primary float-right" type="submit" onclick="window.location='<?php echo e(route('createUserForm')); ?>'">
                        <?php echo e(__("Create Distributor")); ?>

                    </button>
                <?php endif; ?>
            <?php elseif(\Route::currentRouteName() == 'agents'): ?>
                <h3 class="w-75 d-inline-block"><?php echo e(__('Agents')); ?></h3>
                <?php if(Auth::user()->category->id == 1): ?>
                    <button class="btn btn-primary float-right" type="submit" onclick="window.location='<?php echo e(route('createUserForm')); ?>'">
                        <?php echo e(__("Create Agent")); ?>

                    </button>
                <?php endif; ?>
            <?php elseif(\Route::currentRouteName() == 'pharmacists'): ?>
                <h3 class="w-75 d-inline-block"><?php echo e(__('Pharmacists')); ?></h3>
                <?php if(Auth::user()->category->id == 3): ?>
                    <button class="btn btn-primary float-right" type="submit" onclick="window.location='<?php echo e(route('createUserForm')); ?>'">
                        <?php echo e(__("Create Pharmacist")); ?>

                    </button>
                <?php endif; ?>
            <?php endif; ?>
            <hr>
        <div class="table-responsive">
        <table class="table table-hover table-bordered table-sm mt-2" id="childrenTable">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col"><?php echo e(__('Name')); ?></th>
                <th scope="col"><?php echo e(__('Second Name')); ?></th>
                <th scope="col"><?php echo e(__('Country')); ?></th>
                <th scope="col"><?php echo e(__('Region')); ?></th>
                <th scope="col"><?php echo e(__('City')); ?></th>
                <th scope="col"><?php echo e(__('Telephone 1')); ?></th>
                <th scope="col"><?php echo e(__('E-Mail Address')); ?></th>
                <th scope="col"><?php echo e(__('Actions')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $availableChildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\Route::currentRouteName() == 'distributors' && $child->category->id != 3): ?>
                <?php continue; ?>
            <?php elseif(\Route::currentRouteName() == 'pharmacists' && $child->category->id != 5): ?>
                <?php continue; ?>
            <?php endif; ?>
            <?php if($child->category->id != 4 && $child->parents->contains('id', Auth::user()->id)): ?>
                <tr <?php if($child->isFreezed): ?> class='table-danger' <?php endif; ?> >
                    <th scope="row"><?php echo e($child->id); ?></th>
                    <td><?php echo e($child->f_name); ?></td>
                    <td><?php echo e($child->s_name); ?></td>
                    <td><?php echo e($child->itsCountry->ar_name); ?></td>
                    <td><?php echo e($child->itsCity->ar_name); ?></td>
                    <td><?php echo e($child->region); ?></td>
                    <td><?php echo e($child->tel1); ?></td>
                    <td><?php echo e($child->email); ?></td>
                    <td>
                        <a class="btn btn-secondary btn-sm" href="/showUsr/<?php echo e($child->id); ?>"><?php echo e(__('Show')); ?></a>
                        <?php if(Auth::user()->category->id == 1): ?>
                            <?php if($child->category->id == 2): ?>
                                <?php if(!$child->parents->isEmpty()): ?>
                                    <?php if(!$child->isVerified): ?>
                                        <a class="btn btn-secondary btn-sm" id="verifyBtn<?php echo e($child->id); ?>" href="#" onclick="verifyRelAjax(<?php echo e($child->id); ?>)"><?php echo e(__('Verify')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-secondary btn-sm btn-disabled disabled" href="#"><?php echo e(__('Verified')); ?></a>
                                    <?php endif; ?>
                                    <?php if(!$child->isFreezed): ?>
                                        <a class="btn btn-danger btn-sm" id="freezeBtn<?php echo e($child->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($child->id); ?>, true)"><?php echo e(__('Freeze')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-info btn-sm" id="freezeBtn<?php echo e($child->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($child->id); ?>, false)"><?php echo e(__('Unfreeze')); ?></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::user()->category->id == 2): ?>
                            <?php if($child->category->id == 3): ?>
                                <?php if(!$child->parents->isEmpty()): ?>
                                    <?php if(!$child->isVerified): ?>
                                        <a class="btn btn-secondary btn-sm" id="verifyBtn<?php echo e($child->id); ?>" href="#" onclick="verifyRelAjax(<?php echo e($child->id); ?>)"><?php echo e(__('Verify')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-secondary btn-sm btn-disabled disabled" href="#"><?php echo e(__('Verified')); ?></a>
                                    <?php endif; ?>
                                    <?php if(!$child->isFreezed): ?>
                                        <a class="btn btn-danger btn-sm" id="freezeBtn<?php echo e($child->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($child->id); ?>, true)"><?php echo e(__('Freeze')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-info btn-sm" id="freezeBtn<?php echo e($child->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($child->id); ?>, false)"><?php echo e(__('Unfreeze')); ?></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </td>
                </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
            </tbody>
        </table>
    </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fixedHeader.bootstrap4.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fixedHeader.bootstrap4.min.css')); ?>" rel="stylesheet">
<script>
    $(document).ready(function() {
      $('#childrenTable').DataTable({fixedHeader: true, 
                "info":     false,
                "oLanguage": {"sSearch": "<i class='fas fa-search'></i>"}
            });
        tablesFunc('childrenTable');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/userRelations/availableChildren/index.blade.php ENDPATH**/ ?>