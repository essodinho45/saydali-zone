<?php $__env->startSection('content'); ?>
<div class="container py-4">
            <h3 class="w-75 d-inline-block"><?php echo e(__('Ads')); ?></h3>
                <button class="btn btn-info float-right" type="submit" onclick="window.location='<?php echo e(route('createAds')); ?>'">
                    <?php echo e(__("Create Ad")); ?>

                </button>
        <div class="table-responsive">
            <table class="table table-hover table-sm table-bordered mt-2" id="adsTable">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th><?php echo e(__('User')); ?></th>
                    <th><?php echo e(__('Position')); ?></th>
                    <th><?php echo e(__('Image')); ?> / <?php echo e(__('Text')); ?></th>
                    <th><?php echo e(__('From Date')); ?></th>
                    <th><?php echo e(__('To Date')); ?></th>
                    <th><?php echo e(__('Actions')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <th scope="row"><?php echo e($ad->id); ?></th>
                        <td> <?php if($ad->user != null): ?> <?php echo e($ad->user->f_name); ?> &nbsp; <?php if($ad->user->s_name != null): ?><?php echo e($ad->user->s_name); ?> <?php endif; ?> <?php endif; ?></td>
                        <td>
                        <?php if($ad->position == 1 || $ad->position == 2): ?>    <?php echo e(__('Home Page')); ?>

                        <?php elseif($ad->position == 3 || $ad->position == 4): ?> <?php echo e(__('Control Panel')); ?>

                        <?php elseif($ad->position == 5 || $ad->position == 6): ?> <?php echo e(__('Items')); ?><?php endif; ?>
                        </td>
                        <td>
                        <?php if($ad->position == 1 || $ad->position == 2): ?>    <?php echo e($ad->text); ?>

                        <?php else: ?> <img src="..<?php echo e($ad->image_url); ?>" class="mb-2 rounded e3img"><?php endif; ?>
                        </td>
                        <td><?php echo e($ad->from_date); ?></td>
                        <td><?php echo e($ad->to_date); ?></td>
                        <td>
                            <form action="<?php echo e(route('deleteAds',['id' => $ad->id])); ?>" method="POST" class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE">
                                <button class="btn btn-danger btn-sm" type="submit">
                                    <?php echo e(__("Delete")); ?>

                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
            <hr>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<script>
    $(document).ready(function() {
      $('#adsTable').DataTable({ fixedHeader: true,
                                "info": false
                            });
    tablesFunc('adsTable');    
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/ads/index.blade.php ENDPATH**/ ?>