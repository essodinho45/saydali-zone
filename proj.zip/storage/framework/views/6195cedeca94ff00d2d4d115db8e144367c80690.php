<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('User Information')); ?></div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <div class="img-sq">
                                <img class="img-fluid rounded-circle m-2" src="<?php echo e(asset($user->logo_image)); ?>">
                            </div>
                        </div>
                        <div class="col-8">
                            <h1>
                                <?php echo e($user->f_name); ?>&nbsp;<?php echo e($user->s_name); ?>

                            </h1>
                            <hr>
                            <?php if($user->tel1 != null): ?> <h5><i class="fas fa-phone mr-3"></i><?php echo e($user->tel1); ?>&nbsp;<?php if($user->tel2 != null): ?>- <?php echo e($user->tel2); ?> <?php endif; ?> </h5> <?php endif; ?>
                            <?php if($user->mob1 != null): ?> <h5><i class="fas fa-mobile-alt mr-4"></i><?php echo e($user->mob1); ?>&nbsp;<?php if($user->mob2 != null): ?>- <?php echo e($user->mob2); ?> <?php endif; ?> </h5> <?php endif; ?>
                            <?php if($user->fax1 != null): ?> <h5><i class="fas fa-fax mr-3"></i><?php echo e($user->fax1); ?>&nbsp;<?php if($user->fax2 != null): ?>- <?php echo e($user->fax2); ?> <?php endif; ?> </h5> <?php endif; ?>
                            <h5><i class="fas fa-at mr-3"></i><?php echo e($user->email); ?>&nbsp;<?php if($user->email2 != null): ?>- <?php echo e($user->email2); ?> <?php endif; ?> </h5>
                            <h5><i class="fas fa-map-marker-alt mr-4"></i><?php echo e($user->itsCountry->ar_name); ?>&nbsp;-&nbsp;<?php echo e($user->itsCity->ar_name); ?><?php if($user->region != null): ?>&nbsp;-&nbsp;<?php echo e($user->region); ?><?php endif; ?> <?php if($user->address != null): ?>&nbsp;-&nbsp;<?php echo e($user->address); ?><?php endif; ?> </h5>
                        </div>

                    </div>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if($user->user_category_id == 2 && Auth::user()->category->id == 0): ?>
                    <hr>
                    <form method="POST" action="/addDist/<?php echo e($user->id); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                                <label class="col-md-3 text-right" for="dist"><?php echo e(__("Distributor")); ?> *</label>
                                <div class="col-md-6">
                                    <select class="form-control w-100" id="dist" class="form-control <?php $__errorArgs = ['dist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dist" value="<?php echo e(old('dist')); ?>" required>
                                        <?php $__currentLoopData = $dists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dist->id); ?>"><?php echo e($dist->f_name); ?>&nbsp; <?php if($dist->s_name): ?><?php echo e($dist->s_name); ?><?php endif; ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['dist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3">
                                <button type="submit" class="btn btn-lightkiwi">
                                    <?php echo e(__('Add')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>
                    <?php if(Auth::user()->category->id == 0): ?>
                    <hr>
                        <?php if($user->email_verified_at == null): ?>
                            <a class="btn btn-info float-right mx-1" id="verBtn<?php echo e($user->id); ?>" href="#" onclick="verUsrAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Verify')); ?></a>
                        <?php endif; ?>
                        <?php if($user->user_category_id != 0): ?>
                            <?php if($user->freezed == false): ?>
                                <a class="btn btn-danger float-right mx-1" id="frzUsrBtn<?php echo e($user->id); ?>" href="#" onclick="frzUsrAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Freeze')); ?></a>
                            <?php elseif($user->freezed == true): ?>
                                <a class="btn btn-secondary float-right mx-1" id="unfrzUsrBtn<?php echo e($user->id); ?>" href="#" onclick="unfrzUsrAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Unfreeze')); ?></a>
                            <?php endif; ?>
                            <?php if($user->items->count()==0
                            && $user->ordersFromUser->count()==0
                            && $user->ordersToUser->count()==0
                            && $user->cartsFromUser->count()==0
                            && $user->cartsToUser->count()==0
                            && $user->posts->count()==0
                            && $user->offers->count()==0
                            && $user->quantities->count()==0
                            && $user->baskets->count()==0): ?>
                                <form action="<?php echo e(route('deleteUser',['id' => $user->id])); ?>" method="POST" class="d-inline-block float-right mx-1">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-danger mx-1" type="submit">
                                        <?php echo e(__("Delete")); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if((Auth::user()->category->id == 1 || Auth::user()->category->id == 2) && $user->parents->contains(Auth::user()->id)): ?>
                        <hr>
                        <?php if(Auth::user()->category->id == 1): ?>
                            <?php if($user->category->id == 2): ?>
                                <?php if(!$user->parents->isEmpty()): ?>
                                    <?php if(!$user->parents->where('id',Auth::user()->id)->first()->pivot->verified): ?>                                    
                                        <a class="btn btn-secondary float-right mx-1" id="verifyBtn<?php echo e($user->id); ?>" href="#" onclick="verifyRelAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Verify')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-secondary btn-disabled disabled float-right mx-1" href="#"><?php echo e(__('Verified')); ?></a>
                                    <?php endif; ?>
                                    <?php if(!$user->parents->where('id',Auth::user()->id)->first()->pivot->freezed): ?>
                                        <a class="btn btn-danger float-right mx-1" id="freezeBtn<?php echo e($user->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($user->id); ?>, true)"><?php echo e(__('Freeze')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-info float-right mx-1" id="freezeBtn<?php echo e($user->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($user->id); ?>, false)"><?php echo e(__('Unfreeze')); ?></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::user()->category->id == 2): ?>
                            <?php if($user->category->id == 3): ?>
                                <?php if(!$user->parents->isEmpty()): ?>
                                    <?php if(!$user->parents->where('id',Auth::user()->id)->first()->pivot->verified): ?>
                                        <a class="btn btn-secondary float-right mx-1" id="verifyBtn<?php echo e($user->id); ?>" href="#" onclick="verifyRelAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Verify')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-secondary btn-disabled disabled float-right mx-1" href="#"><?php echo e(__('Verified')); ?></a>
                                    <?php endif; ?>
                                    <?php if(!$user->parents->where('id',Auth::user()->id)->first()->pivot->freezed): ?>
                                        <a class="btn btn-danger float-right mx-1" id="freezeBtn<?php echo e($user->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($user->id); ?>, true)"><?php echo e(__('Freeze')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-info float-right mx-1" id="freezeBtn<?php echo e($user->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($user->id); ?>, false)"><?php echo e(__('Unfreeze')); ?></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if( in_array(Auth::user()->category->id, [2,3,4])): ?>                            
                    <hr>
                        <?php if(Auth::user()->category->id == 4): ?>
                            <?php if($user->category->id != 5): ?>
                                <?php if(!$user->children->isEmpty() && $user->children->contains('id', Auth::user()->id)): ?>
                                    <?php if(!$user->children->where('id',Auth::user()->id)->first()->pivot->freezed): ?>
                                        <a class="btn btn-danger float-right mx-1" id="freezeBtn<?php echo e($user->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($user->id); ?>, true)"><?php echo e(__('Freeze')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-info float-right mx-1" id="freezeBtn<?php echo e($user->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($user->id); ?>, false)"><?php echo e(__('Unfreeze')); ?></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a class="btn btn-secondary float-right mx-1" id="addBtn<?php echo e($user->id); ?>" href="#" onclick="addParentAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Add')); ?></a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::user()->category->id == 2): ?>
                            <?php if($user->category->id == 1): ?>
                                <?php if(!$user->children->isEmpty() && $user->children->contains('id', Auth::user()->id)): ?>
                                    <?php if(!$user->children->where('id',Auth::user()->id)->first()->pivot->verified): ?>
                                        <a class="btn btn-secondary btn-disabled disabled float-right mx-1" href="#"><?php echo e(__('Requested')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-secondary btn-disabled disabled float-right mx-1" href="#"><?php echo e(__('Verified')); ?></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a class="btn btn-secondary float-right mx-1" id="reqBtn<?php echo e($user->id); ?>" href="#" onclick="reqRelAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Request')); ?></a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::user()->category->id == 3): ?>
                            <?php if($user->category->id == 2): ?>
                                <?php if(!$user->children->isEmpty() && $user->children->contains('id', Auth::user()->id)): ?>
                                    <?php if(!$user->children->where('id',Auth::user()->id)->first()->pivot->verified): ?>
                                        <a class="btn btn-secondary btn-disabled disabled float-right mx-1" href="#"><?php echo e(__('Requested')); ?></a>
                                    <?php else: ?>
                                        <a class="btn btn-secondary btn-disabled disabled float-right mx-1" href="#"><?php echo e(__('Verified')); ?></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a class="btn btn-secondary float-right mx-1" id="reqBtn<?php echo e($user->id); ?>" href="#" onclick="reqRelAjax(<?php echo e($user->id); ?>)"><?php echo e(__('Request')); ?></a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/userRelations/show.blade.php ENDPATH**/ ?>