<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
    <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $post->author->id): ?>
        <div class="container py-4">
                <form action="<?php echo e(route('updatePost',['id' => $post->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                                <label for="title"><?php echo e(__('Title')); ?></label>
                                <input type="text" class="form-control" id="title" name="title" value="<?php echo e($post->title); ?>">
                        </div>
                        <div class="form-group">
                                <label for="content"><?php echo e(__('Content')); ?></label>
                                <textarea class="form-control" rows="5" id="content" name="content"><?php echo e($post->content); ?></textarea>
                        </div>
                        <!-- Input tags go here -->
                        <button class="btn btn-info" type="submit">
                            <?php echo e(__("Update Post")); ?>

                        </button>
                </form>
                <form action="<?php echo e(route('deletePost',['id' => $post->id])); ?>" method="POST" class="mt-2">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button class="btn btn-danger" type="submit">
                            <?php echo e(__("Delete Post")); ?>

                        </button>
                </form>
        </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/posts/edit.blade.php ENDPATH**/ ?>