<?php $__env->startSection('content'); ?>
<div class="container py-4">
            <h3 class="w-75 d-inline-block"><?php echo e(__('Offers')); ?></h3>
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->user_category_id == 2 || Auth::user()->user_category_id == 3 || Auth::user()->user_category_id == 0): ?>
                <button class="btn btn-info float-right" type="submit" onclick="window.location='<?php echo e(route('createOffer')); ?>'">
                    <?php echo e(__("Create Offer")); ?>

                </button>
                <?php endif; ?>
            <?php endif; ?>

            <div class="table-responsive">
            <table class="table table-hover table-sm table-bordered nowrap mt-2" id="offersTable">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col"><?php echo e(__('Company')); ?></th>
                    <th scope="col"><?php echo e(__('Item')); ?></th>
                    <th scope="col"><?php echo e(__('Discount')); ?></th>
                    <th scope="col"><?php echo e(__('Quantity')); ?></th>
                    <th scope="col"><?php echo e(__('Free Item')); ?></th>
                    <th scope="col"><?php echo e(__('Free Quantity')); ?></th>
                    <th scope="col"><?php echo e(__('From Date')); ?></th>
                    <th scope="col"><?php echo e(__('To Date')); ?></th>
                    <th scope="col"><?php echo e(__('Actions')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <th scope="row"><?php echo e($offer->id); ?></th>
                        <td><?php echo e($offer->user->f_name); ?></td>
                        <td><?php echo e($offer->item->name); ?></td>
                        <td><?php if($offer->discount != null): ?><?php echo e($offer->discount); ?><?php endif; ?></td>
                        <td><?php if($offer->quant != null): ?><?php echo e($offer->quant); ?><?php endif; ?></td>
                        <td><?php if($offer->freeItem != null): ?><?php echo e($offer->freeItem->name); ?><?php endif; ?></td>
                        <td><?php if($offer->free_quant != null): ?><?php echo e($offer->free_quant); ?><?php endif; ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($offer->from_date))); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($offer->to_date))); ?></td>
                        <td>
                            
                            <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $offer->user_id): ?>
                                
                                <form action="<?php echo e(route('deleteOffer',['id'=>$offer->id, 'type'=>1])); ?>" method="POST" class="d-inline-block">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-danger btn-sm" type="submit">
                                        <?php echo e(__("Delete")); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
            <hr>
            <h3 class="w-75 d-inline-block"><?php echo e(__('Baskets')); ?></h3>
            <div class="table-responsive">
            <table class="table table-hover table-sm table-bordered nowrap mt-2 accordion" id="basketsTable">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col"><?php echo e(__('Company')); ?></th>
                    <th scope="col"><?php echo e(__('Price')); ?></th>
                    <th scope="col"><?php echo e(__('From Date')); ?></th>
                    <th scope="col"><?php echo e(__('To Date')); ?></th>
                    <th scope="col"><?php echo e(__('Actions')); ?></th>
                    
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $baskets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-toggle="collapse" class="clickable" data-target="#collapseBItems<?php echo e($basket->id); ?>" aria-expanded="false" aria-controls="collapseBItems<?php echo e($basket->id); ?>">
                        <th scope="row" rowspan="2"><?php echo e($basket->id); ?></th>
                        <td><?php echo e($basket->user->f_name); ?></td>
                        <td><?php echo e($basket->price); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($basket->from_date))); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($basket->to_date))); ?></td>
                        
                        <td>
                            
                            <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $basket->user_id): ?>
                                
                                <form action="<?php echo e(route('deleteOffer',['id'=>$basket->id, 'type'=>2])); ?>" method="POST" class="d-inline-block">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-danger btn-sm" type="submit">
                                        <?php echo e(__("Delete")); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                        
                        </tr>
                        <tr>
                            <td colspan="5">
                                <div class="collapse" id="collapseBItems<?php echo e($basket->id); ?>">
                                    <?php $__currentLoopData = $basket->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item->name ." ". $item->type->ar_name ." ". $item->titer); ?> : <b><?php echo e($item->pivot->quantity); ?></b>
                                    <br>                                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </td>
                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fixedHeader.bootstrap4.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fixedHeader.bootstrap4.min.css')); ?>" rel="stylesheet">

<script>
    $(document).ready(function() {
      $('#offersTable').DataTable({ fixedHeader: true,"info":     false,
      "oLanguage": {"sSearch": "<i class='fas fa-search'></i>"}
    });                
      tablesFunc('offersTable');
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/offers/index.blade.php ENDPATH**/ ?>