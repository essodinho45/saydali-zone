<?php $__env->startSection('content'); ?>

<div class="container py-4">
            <h3 class="w-75 d-inline-block"><?php echo e(__('News')); ?></h3>
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->user_category_id != 5): ?>
                <button class="btn btn-info float-right" type="submit" onclick="window.location='<?php echo e(route('createPost')); ?>'">
                    <?php echo e(__("Create Post")); ?>

                </button>
                <?php endif; ?>
            <?php endif; ?>
                <div class="p-2">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="card mb-3 NewsCard" onclick="window.location='/news/<?php echo e($post->id); ?>'">
                        <div class="row no-gutters mh-200">
                            <div class="col-4">
                            <img src="<?php echo e(asset($post->author->logo_image)); ?>" class="card-img w-50 py-4" alt="...">
                            </div>
                            <div class="col-6">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($post->author->f_name); ?>&nbsp;<?php echo e($post->author->s_name); ?></h5>
                                <p class="card-text"><?php echo e($post->title); ?></p>
                            <p class="card-text"><small class="text-muted"><?php echo e(__('Last updated')); ?> <?php echo e($post->updated_at->diffForHumans()); ?></small></p>
                            </div>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                                <div class="col-2">
                                    <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $post->author->id): ?>
                                        <a class="btn btn-secondary" href="<?php echo e(route('editPost', ['id'=>$post->id])); ?>" style="margin-top:40%"><?php echo e(__('Edit')); ?></a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($posts->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/posts/index.blade.php ENDPATH**/ ?>