<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-2 bg-transparent text-lightkiwi h-100">
            <?php $__currentLoopData = $ads1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="..<?php echo e($ads->image_url); ?>" class="w-100 h-100 mb-2 rounded"> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="alert alert-success" role="alert">
                                <?php if(session('message') != null): ?>
                                    <?php echo e(session('message')); ?> 
                                    <br>
                                <?php endif; ?>
                                <?php echo e(__('Welcome')); ?> <?php echo e(Auth::user()->f_name); ?> <?php echo e(Auth::user()->s_name); ?> , <?php echo e(__('you\'re logged in')); ?>.
                        </div>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('items')); ?>" role="button"><i class="fas fa-pills mr-2"></i><?php echo e(__('Items')); ?></a>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('editUser', ['id'=>Auth::user()->id])); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('My Account')); ?></a>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('editPassword')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Change Password')); ?></a>
                    <?php if(Auth::user()->category->id == 1): ?>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('agents')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Agents')); ?></a>
                    <?php endif; ?>
                    
                    <?php if(Auth::user()->category->id == 2): ?>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('distributors')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Distributors')); ?></a>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('pharmacists')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Pharmacists')); ?></a>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('companies')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Companies')); ?></a>
                    <?php endif; ?>
                    <?php if(Auth::user()->category->id == 4): ?>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('companies')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Companies')); ?></a>
                    <?php endif; ?>
                    <?php if(Auth::user()->category->id == 5): ?>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('showFav')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Favourite Distributors')); ?></a>
                    <?php endif; ?>
                    <?php if(Auth::user()->category->id == 0): ?>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('allUsers')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Manage Users')); ?></a>
                    <a class="btn btn-lg btn-lightkiwi mb-1" href="<?php echo e(route('ads')); ?>" role="button"><i class="fas fa-user-circle mr-2"></i><?php echo e(__('Manage Ads')); ?></a>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-2 bg-transparent text-lightkiwi h-100">
            <?php $__currentLoopData = $ads2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="..<?php echo e($ads->image_url); ?>" class="w-100 h-100 mb-2 rounded"> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/home.blade.php ENDPATH**/ ?>