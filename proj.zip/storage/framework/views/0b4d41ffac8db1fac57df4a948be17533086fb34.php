<?php $__env->startSection('content'); ?>
<div class="d-none"><?php echo e($totalprice = 0); ?></div>
<div class="container py-4">
    <?php if(auth()->guard()->check()): ?>
        <h2><?php echo e(__("Order")); ?></h2>            
        <small class="text-muted"><?php echo e(__('Order Number')); ?>: <?php echo e($order->id); ?> - <?php echo e($order->created_at->format('d/m/Y')); ?>&nbsp; <?php echo e($order->created_at->format('H:i:s')); ?></small>
        <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $order->reciever->id): ?>
        <button class="btn btn-secondary float-right" onclick="printPage()" id="prtbtn">
            <i class="fas fa-print"></i>
        </button>
        <?php endif; ?>
        <br>
            <div class="p-2">
                <div>
                    <div class="row col-12 p-0">
                        <div class="col-md-3">
                            <h6><?php echo e(__('Sender')); ?></h6>
                            <p>
                                <?php echo e($order->sender->f_name); ?> <?php echo e($order->sender->s_name); ?>

                            </p>
                        </div>
                        <div class="col-md-3">
                            <h6><?php echo e(__('Reciever')); ?></h6>
                            <p>
                                <?php echo e($order->reciever->f_name); ?> <?php echo e($order->reciever->s_name); ?>

                            </p>
                        </div>
                        <div class="col-md-3">
                            <h6><?php echo e(__('Sender Address')); ?></h6>
                            <p>
                                <?php echo e($order->sender->itsCountry->ar_name); ?>, <?php echo e($order->sender->itsCity->ar_name); ?>, <?php if($order->sender->region != null): ?> <?php echo e($order->sender->region); ?>, <?php endif; ?> <?php if($order->sender->address != null): ?> <?php echo e($order->sender->address); ?> <?php endif; ?> .
                            </p>
                        </div>
                        <div class="col-md-3">
                            <h6><?php echo e(__('Sender Phone')); ?></h6>
                            <p>
                                <?php echo e($order->sender->mob1); ?> <?php if($order->sender->tel1 != null): ?> - <?php echo e($order->sender->tel1); ?> <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <hr>
                    <h6><?php echo e(__('Items')); ?></h6>
                    <div class="table-responsive">
                            <table class="table table-hover table-sm table-bordered mt-2" id="ItemsTable">
                                    <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col"><?php echo e(__('Name')); ?></th>
                                        <th scope="col"><?php echo e(__('Producer')); ?></th>
                                        <th scope="col"><?php echo e(__('Price')); ?></th>
                                        <th scope="col"><?php echo e(__('Type')); ?></th>
                                        <th scope="col"><?php echo e(__('Quantity')); ?></th>
                                        <th scope="col"><?php echo e(__('Free Quantity')); ?></th>
                                        <th scope="col"><?php echo e(__('Total Price')); ?></th>
                                        <th scope="col"><?php echo e(__('Discounted Price')); ?></th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row" rowspan="2"><?php echo e($item->id); ?></th>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->company->f_name); ?></td>
                                            <td><?php echo e($item->price); ?></td>
                                            <td><?php echo e($item->type->ar_name); ?></td>
                                            <td><?php echo e($item->pivot->quantity); ?></td>
                                            <td><?php echo e($item->pivot->free_quant); ?></td>
                                            <td><?php echo e($item->pivot->quantity * $item->price); ?> <?php echo e(__("S.P.")); ?></td>
                                            <td><?php echo e($item->pivot->price); ?> <?php echo e(__("S.P.")); ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3"><?php echo e(__('Sender Remark')); ?>: <?php echo e($item->pivot->sender_remark); ?></td>
                                            <td colspan="3"><?php echo e(__('Reciever Remark')); ?>: <?php echo e($item->pivot->reciever_remark); ?></td>
                                            <td colspan="2" id="trow">
                                                <?php if(Auth::user()->id == $order->reciever->id && $order->verified_at == null && $item->pivot->verified_at == null): ?>
                                                    <a class="btn btn-sm btn-secondary" title="<?php echo e(__('Insert Reciever Remark')); ?>" href="#" onclick="openVerItModal(<?php echo e($order->id); ?>,<?php echo e($item->id); ?>)"><i class="fas fa-comment"></i></a>
                                                    <a id="verOrdItmBtn<?php echo e($order->id); ?><?php echo e($item->id); ?>" class="btn btn-sm btn-secondary" href="#" onclick="verItemInOrder(<?php echo e($order->id); ?>,<?php echo e($item->id); ?>)"><?php echo e(__('Verify')); ?></a>
                                                <?php elseif($order->verified_at == null && $item->pivot->verified_at != null): ?>
                                                    <a class="btn btn-sm btn-secondary disabled" href="#"><?php echo e(__('Verified')); ?></a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $order->baskets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-toggle="collapse" class="clickable" data-target="#collapseBItems<?php echo e($item->id); ?>" aria-expanded="false" aria-controls="collapseBItems<?php echo e($item->id); ?>">
                                            <th scope="row"><?php echo e($item->id); ?></th>
                                            <td><?php echo e(__('Basket')); ?></td>
                                            <td><?php echo e($item->user->f_name); ?></td>
                                            <td><?php echo e($item->price); ?></td>
                                            <td></td>
                                            <td></td>
                                            <td><?php echo e($item->pivot->quantity); ?></td>
                                            <td></td>
                                            <td><?php echo e($item->pivot->quantity * $item->price); ?> <?php echo e(__("S.P.")); ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="9">
                                                <div class="collapse" id="collapseBItems<?php echo e($item->id); ?>">
                                                    <?php $__currentLoopData = $item->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($itemm->name ." ". $itemm->type->ar_name ." ". $itemm->titer); ?> : <b><?php echo e($itemm->pivot->quantity); ?></b>
                                                    <br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                        </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                    <hr>
                    <div class="row col-12 p-0 pt-2">
                        <div class="col-6">
                            <h6><?php echo e(__('Sender Remark')); ?></h6>
                            <?php if($order->remark != 'null'): ?>
                                <p><?php echo e($order->remark); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col-6">
                            <h6><?php echo e(__('Reciever Remark')); ?></h6>
                            <?php if($order->reciever_remark != 'null'): ?>
                                <p><?php echo e($order->reciever_remark); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <h4><?php echo e(__('Total Price')); ?></h4>
                    <h6>
                        <?php echo e($order->price); ?> <?php echo e(__('S.P.')); ?>

                    </h6>
                </div>
            </div>
            <div class="mb-4" id="btns">
                <?php if(Auth::user()->user_category_id == 0 || Auth::user()->id == $order->sender->id || Auth::user()->id == $order->reciever->id): ?>                    
                            <?php if(Auth::user()->id == $order->reciever->id && $order->verified_at == null): ?>
                            <form action="<?php echo e(route('verifyOrder',['id' => $order->id])); ?>" method="POST" class="ml-1 float-right" id="verForm">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button class="btn btn-secondary" type="submit">
                                        <?php echo e(__("Verify Order")); ?>

                                </button>
                            </form>
                            <button class="btn btn-secondary float-right" data-toggle="modal" title=<?php echo e(__("Insert Reciever Remark")); ?> data-target="#sender_remark">
                                <i class="fas fa-comment"></i>
                            </button>
                            <?php elseif($order->verified_at != null): ?>
                                <a class="btn btn-secondary disabled float-right" href="#"><?php echo e(__('Verified')); ?></a>
                            <?php endif; ?>
                            <?php if(Auth::user()->id == 0): ?>
                                <form action="<?php echo e(route('deleteOrder',['id' => $order->id])); ?>" method="POST" class="float-right">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="DELETE">
                                        <button class="btn btn-danger" type="submit">
                                                <?php echo e(__("Delete Order")); ?>

                                        </button>
                                </form>
                            <?php endif; ?>
                    </form>
                <?php endif; ?>
            </div>
    <?php endif; ?>
</div>
<div class="modal fade" id="reciever_remark_item" tabindex="-1" role="dialog" aria-labelledby="reciever_remark_item_Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="reciever_remark_item_Label"><?php echo e(__('Reciever Remark')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="order_item_id">
            <input type="hidden" id="item_id">
            <label for="reciever_remark_item_txt"><?php echo e(__('Reciever Remark')); ?></label>
            <textarea id="reciever_remark_item_txt" class="form-control w-100"></textarea>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="verItemInOrder()"><?php echo e(__('Verify')); ?></button>
        </div>
    </div>
    </div>
</div>
    <!-- Modal -->
    <div class="modal fade" id="sender_remark" tabindex="-1" role="dialog" aria-labelledby="reciever_remarkLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="reciever_remarkLabel"><?php echo e(__('Reciever Remark')); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="order_id">
                <label for="reciever_remark_txt"><?php echo e(__('Reciever Remark')); ?></label>
                <textarea id="reciever_remark_txt" class="form-control w-100" onchange="addRem2form()"></textarea>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
            <form action="<?php echo e(route('verifyOrder',['id' => $order->id])); ?>" method="POST" class="mr-1 float-right" id="verForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" id="reciever_remark" name="reciever_remark">
                <button class="btn btn-secondary" type="submit">
                        <?php echo e(__("Verify Order")); ?>

                </button>
            </form>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
        
        function openVerItModal(ord,itm)
        {
            $('#order_item_id').val(ord);
            $('#item_id').val(itm);
            $('#reciever_remark_item').modal('show');
            
        }
        function addRem2form(){
            $('#reciever_remark').val($('#reciever_remark_txt').val());
        }
        function printPage(){
            $('#prtbtn').addClass('d-none');
            $('#btns').addClass('d-none');
            $('#trow').html('');
            window.print();
            return location.reload();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/orders/show.blade.php ENDPATH**/ ?>