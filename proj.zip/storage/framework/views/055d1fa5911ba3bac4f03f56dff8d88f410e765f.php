<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->check()): ?>
    <div class="container py-4">
            <h3 class="w-75 d-inline-block"><?php echo e(__('Agents')); ?></h3>
            <hr>
        <table class="table table-hover table-sm mt-2" id="AgentsTable">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col"><?php echo e(__('Name')); ?></th>
                <th scope="col"><?php echo e(__('Second Name')); ?></th>
                <th scope="col"><?php echo e(__('Country')); ?></th>
                <th scope="col"><?php echo e(__('Region')); ?></th>
                <th scope="col"><?php echo e(__('City')); ?></th>
                <th scope="col"><?php echo e(__('Telephone 1')); ?></th>
                <th scope="col"><?php echo e(__('E-Mail Address')); ?></th>
                <th scope="col"><?php echo e(__('Add Agent')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                    <th scope="row"><?php echo e($agent->id); ?></th>
                    <td><?php echo e($agent->f_name); ?></td>
                    <td><?php echo e($agent->s_name); ?></td>
                    <td><?php echo e($agent->itsCountry->ar_name); ?></td>
                    <td><?php echo e($agent->itsCity->ar_name); ?></td>
                    <td><?php echo e($agent->region); ?></td>
                    <td><?php echo e($agent->tel1); ?></td>
                    <td><?php echo e($agent->email); ?></td>
                    <td>
                        <?php if(!$agent->parents->isEmpty() && $agent->parents->contains('id', Auth::user()->id)): ?>
                            <?php if(!$agent->isFreezed): ?>
                                <a class="btn btn-danger btn-sm" id="freezeBtn<?php echo e($agent->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($agent->id); ?>, true)"><?php echo e(__('Freeze')); ?></a>
                            <?php else: ?>
                                <a class="btn btn-info btn-sm" id="freezeBtn<?php echo e($agent->id); ?>" href="#" onclick="freezeRelAjax(<?php echo e($agent->id); ?>, false)"><?php echo e(__('Unfreeze')); ?></a>
                            <?php endif; ?>
                        <?php else: ?>
                        <a class="btn btn-secondary btn-sm" id="addBtn<?php echo e($agent->id); ?>" href="#" onclick="addChildAjax(<?php echo e($agent->id); ?>)"><?php echo e(__('Add')); ?></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
            </tbody>
        </table>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/userRelations/agents/index.blade.php ENDPATH**/ ?>