<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <?php if(Auth::user()->user_category_id != 5): ?>
    <div class="row justify-content-center">
        <div class="col-md-8" id="FavAgForm">
            <div class="card">
                <div class="card-header bg-lightkiwi"><?php echo e(__('Orders Report')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('updateOrdersReport')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(Auth::user()->user_category_id == 0 || Auth::user()->user_category_id == 2): ?>
                        <div class="form-group row">                            
                            
                            <?php if(Auth::user()->user_category_id == 0): ?>
                            <label class="col-md-3 text-right" for="agent"><?php echo e(__("Agent")); ?> *</label>
                            <?php else: ?>
                            <label class="col-md-3 text-right" for="agent"><?php echo e(__("Distributor")); ?> *</label>
                            <?php endif; ?>
                                <div class="col-md-6">
                                    <select class="form-control" id="agentFavAg" class="form-control <?php $__errorArgs = ['agent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="agent" value="<?php echo e(old('agent')); ?>">
                                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($agent->id); ?>"><?php echo e($agent->f_name); ?>&nbsp;<?php echo e($agent->s_name); ?></option>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['agent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="form-group row">
                                <label class="col-md-3" for="from_date"><?php echo e(__("From Date")); ?></label>
                                <div class="col-md-3">
                                        <input id="from_date" type="date" class="form-control <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="from_date" value="<?php echo e(old('from_date')); ?>">

                                        <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <label class="col-md-3" for="to_date"><?php echo e(__("To Date")); ?></label>
                                <div class="col-md-3">
                                        <input id="to_date" type="date" class="form-control <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="to_date" value="<?php echo e(old('to_date')); ?>">

                                        <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3">
                                <button type="submit" class="btn btn-lightkiwi">
                                    <?php echo e(__('Update Report')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>            
        </div>
        <div class="col-12 mt-4 table-responsive">
        <table class="table table-hover table-sm table-bordered nowrap" id="OrdersTable">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col"><?php echo e(__('Sender Name')); ?></th>
                <th scope="col"><?php echo e(__('Reciever Name')); ?></th>
                <th scope="col"><?php echo e(__('Date')); ?></th>
                <th scope="col"><?php echo e(__('Time')); ?></th>
                <th scope="col"><?php echo e(__('Price')); ?></th>
                
                <th scope="col"><?php echo e(__('Actions')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                    <th scope="row"><?php echo e($order->id); ?></th>
                    <td><?php echo e($order->sender->f_name); ?> <?php echo e($order->sender->s_name); ?></td>
                    <td><?php echo e($order->reciever->f_name); ?> <?php echo e($order->reciever->s_name); ?></td>
                    <td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                    <td class="cvrt2tz"><?php echo e($order->created_at->format('H:i:s')); ?></td>
                    <td><?php echo e($order->price); ?></td>
                    
                    <td>
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('showOrder', ['id'=>$order->id])); ?>"><?php echo e(__('Show')); ?></a>                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div>
    <div class="mt-4" id="totalCount">
        <h3><?php echo e(__('Total Price')); ?> :&nbsp; <?php echo e($orders->sum('price')); ?>&nbsp;<?php echo e(__('S.P.')); ?></h3>
        <h5><?php echo e(__('Orders Count')); ?> :&nbsp; <?php echo e($orders->count()); ?></h5>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/table.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fixedHeader.bootstrap4.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/table.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fixedHeader.bootstrap4.min.css')); ?>" rel="stylesheet">
<script>
    // function pwtt(x)
    // {
    // }
$(document).ready(function() {
    $('select').select2();
    $('#OrdersTable').DataTable({
        fixedHeader: true,
        "info":     false,
        "oLanguage": {"sSearch": "<i class='fas fa-search'></i>"},
         dom: 'Bfrtip', 
    buttons: [
            {
                extend: 'print',
                customize: function ( win ) {
                    $(win.document.body)
                        .css( 'font-size', '10pt' )
                        .attr('dir','rtl')
                        .append('<div style="margin-top: 20px;">'+$('#totalCount').html()+'</div>');
 
                    $(win.document.body).find( 'table' )
                        .addClass( 'compact' )
                        .css( 'font-size', 'inherit' );
 
                    $(win.document.body).find('td:last-child').addClass( 'd-none' );
                    $(win.document.body).find('th:last-child').addClass( 'd-none' );
                }
            } 
        ]});
        $('.buttons-print').html('<i class="fas fa-print"></i>');
        tablesFunc('OrdersTable');
  });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\proj\resources\views/reports/orders.blade.php ENDPATH**/ ?>